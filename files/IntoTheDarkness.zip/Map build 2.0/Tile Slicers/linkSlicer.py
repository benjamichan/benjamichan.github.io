#############################################
## Always do this step
#############################################

import os, sys
import pygame
from pygame.locals import *
clock = pygame.time.Clock()    
 

if not pygame.font: print 'Warning, fonts disabled'
if not pygame.mixer: print 'Warning, sound disabled'

ROOT_DIR = "C:/Users/Ben/Dropbox/CMU/CMU Spring/CS112/Term Project Final/Map build 2.0"

def rootName(name):
    return ROOT_DIR + "/" + name
    
def loadTileTable(filename, width, height):
    image = pygame.image.load(rootName(filename)).convert()
    imageWidth, imageHeight = image.get_size()
    tileTable = []
    for tileX in range(0, imageWidth/width-1):
        row = []
        for tileY in range(0, imageHeight/height-1):
            cutTile = (8+tileX*width, 8+tileY*height, width, height)
            row.append(image.subsurface(cutTile))
        tileTable.append(row)
    return tileTable
    
if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((2000, 2000))
    screen.fill((255, 255, 255))
    table = loadTileTable("link.png", 32, 32)
    for x, row in enumerate(table):
        for y, tile in enumerate(row):
            screen.blit(tile, (x*50, y*50))
    pygame.display.flip()

while True:
    clock.tick(60) #limit 60 fp    
    for event in pygame.event.get(): # User did something
        if event.type == pygame.QUIT: # If user clicked close
            sys.exit()